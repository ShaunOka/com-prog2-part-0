/*
 * Name of Student/Programmers:
 * Balanza, Clian
 * Morano, Ian
 * Oka, Shaun Gerald
 * Orlino, Maki
 * Perdido, Jiro
 * Torres, Kate
 * CLASS CODE & Schedule: 9308A/9308B & 2:30pm - 3:30pm MTH (9308A) / 1:30pm - 3:00 pm TF (9308B)
 * Date: March , 2024
 * Instructor: Dale D. Miguel
 */
// code ni Shaun
package edu.slu.prog2;

import java.util.Scanner;

public class FractionTester {
    static Scanner kbd = new Scanner(System.in);

    /**
     * main entry of the program
     * @param args
     */
    public static void main(String[] args) {
        FractionTester groupTester;
        try {
            groupTester = new FractionTester();
            groupTester.run();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * manages the main method of the program
     * @throws Exception
     */
    public void run() throws Exception {
        Fraction result = new Fraction();
        byte type = (byte) 0;
        byte choice = (byte) 0;
        System.out.println("Welcome to Fraction Tester!");
        while (choice != 6) {
            displayMenu();
            choice = (byte) readNumber("Please enter number of choice: ", 1, 6);
            if (choice != 6) {
                displayFractionType(choice);
                type = (byte) readNumber("Please enter number of choice: ", 1, 3);
            }
            switch (choice) {
                case 1 -> result = readFraction1(type).add(readFraction2(type));
                case 2 -> result = readFraction1(type).subtract(readFraction2(type));
                case 3 -> result = readFraction1(type).multiplyBy(readFraction2(type));
                case 4 -> result = readFraction1(type).divideBy(readFraction2(type));
                case 5 -> result = readFraction1(type).simplify();
                case 6 -> {
                    System.out.println("""
                            Thank you for using Fraction Tester!
                            Tester exiting...""");
                    return;
                }
            }
            System.out.printf("Result: %s or %.2f%n", result.simplify(), result.toDouble());
            System.out.print("Please press enter to continue...");
            kbd.nextLine();
        }
    }

    /**
     * displays the arithmetic operations menu for user
     */
    private void displayMenu() {
        System.out.println("""
                * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
                |    Please choose:              |
                |    1.) Add                     |
                |    2.) Subtract                |
                |    3.) Multiply                |
                |    4.) Divide                  |
                |    5.) Simplify                |
                |    6.) Exit                    |
                * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *""");
    }

    /**
     * prompts the user to enter a number
     * @param prompt
     * @param min
     * @param max
     * @return
     */
    public int readNumber(String prompt, int min, int max) {
        int number = 0;
        boolean validInput = false;
        while (!validInput) {
            System.out.printf("%s", prompt);
            try {
                number = Integer.parseInt(kbd.nextLine());
                if (number >= min && number <= max) {
                    validInput = true;
                } else {
                    System.out.printf("Please enter a number with a minimum of %d and a maximum of %d.%n", min, max);
                }
            } catch (NumberFormatException exception) {
                System.out.println("ERROR: Invalid number.");
                System.out.println("Please try again.");
            }
        }
        return number;
    }

    public int readNumberNotZero(String prompt, int min, int max) {
        int number = 0;
        boolean validInput = false;
        while (!validInput) {
            System.out.printf("%s", prompt);
            try {
                number = Integer.parseInt(kbd.nextLine());
                if (number >= min && number <= max && number != 0) {
                    validInput = true;
                } else {
                    System.out.printf("Please enter a NON-ZERO number with a minimum of %d and a maximum of %d.%n", min, max);
                }
            } catch (NumberFormatException exception) {
                System.out.println("ERROR: Invalid number.");
                System.out.println("Please try again.");
            }
        }
        return number;
    }

    /**
     * displays the fraction type for the user
     */
    private void displayFractionType(byte choice) {
        if (choice != 5) {
            System.out.println("""
                    * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
                    |    Please choose fractions:    |
                    |    1.) Two Im/Proper           |
                    |    2.) Mixed and Im/Proper     |
                    |    3.) Two Mixed               |
                    * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *""");
        } else {
            System.out.println("""
                    * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
                    |    Please choose fraction:     |
                    |    1.) Im/Proper               |
                    |    2.) Mixed                   |
                    * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *""");
        }
    }

    public Fraction readFraction1(byte type) {
        Fraction result = new Fraction();
        int numerator = 0;
        int denominator = 1;
        int wholeNumber = 0;
        System.out.println("Please enter a fraction (1)");
        switch (type) {
            case 1:
                numerator = readNumber("Please enter numerator: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                denominator = readNumberNotZero("Please enter denominator: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                result = new Fraction(numerator, denominator);
                break;
            case 2:
            case 3:
                wholeNumber = readNumber("Please enter a whole number: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                numerator = readNumber("Please enter numerator: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                denominator = readNumberNotZero("Please enter denominator: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                result = new MixedFraction(wholeNumber, numerator, denominator);
                break;
        }
        return result;
    }

    public Fraction readFraction2(byte type) {
        Fraction result = new Fraction();
        int numerator = 0;
        int denominator = 1;
        int wholeNumber = 0;
        System.out.println("Please enter a fraction (2)");
        switch (type) {
            case 1:
            case 2:
                numerator = readNumber("Please enter numerator: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                denominator = readNumberNotZero("Please enter denominator: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                result = new Fraction(numerator, denominator);
                break;
            case 3:
                wholeNumber = readNumber("Please enter a whole number: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                numerator = readNumber("Please enter numerator: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                denominator = readNumberNotZero("Please enter denominator: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                result = new MixedFraction(wholeNumber, numerator, denominator);
                break;
        }
        return result;
    }
}

/*
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FractionTester extends JFrame{
    private JLabel firstFractionL, secondFractionL, resultFractionL;
    private JTextField firstNumeratorTF, firstDenominatorTF,  secondNumeratorTF, secondDenominatorTF, resultFractionTF;
    private JButton addB, subtractB, multiplyB, divideB, simplifyB, clearB, exitB;
    private AddButtonHandler addHandler;
    private SubtractButtonHandler subtractHandler;
    private MultiplyByButtonHandler multiplyByHandler;
    private DivideByButtonHandler divideByHandler;
    private SimplifyButtonHandler simplifyHandler;
    private ClearButtonHandler clearHandler;
    private ExitButtonHandler exitHandler;
    private static final int WIDTH = 400;
    private static final int HEIGHT = 300;
    public FractionTester() {
        firstFractionL = new JLabel("Enter first fraction");
    }
    public static void main(String[] args) {
        FractionTester groupTester;
        try {
            groupTester = new FractionTester();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    private class AddButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {

        }
    }

    private class SubtractButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {

        }
    }

    private class MultiplyByButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {

        }
    }

    private class DivideByButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {

        }
    }

    private class SimplifyButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {

        }
    }

    private class ClearButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {

        }
    }
    private class ExitButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {

        }
    }
}

 */

