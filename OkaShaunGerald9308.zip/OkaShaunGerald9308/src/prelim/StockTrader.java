/*
 * Name of Student/Programmer: Oka, Shaun Gerald D.
 * CLASS CODE & Schedule: 9308A/9308B & 2:30pm - 3:30pm MTH (9308A) / 1:30pm - 3:00 pm TF (9308B)
 * Date: February 13, 2024
 * Instructor: Dale D. Miguel
 */
package prelim;

// Reference Class for StockTrader
public class StockTrader {
    private String firstName = "";
    private String middleName = "";
    private String lastName = "";
    private String fullName = "";
    private String stockName = "";
    private int numberOfStocks;

    /**
     * Constructs a stock trader named Oka, Shaun Gerald De Leon, who owns 10 Tesla stocks.
     */
    public StockTrader() {
        firstName = "Shaun Gerald";
        middleName = "De Leon";
        lastName = "Oka";
        fullName = "Oka, Shaun Gerald De Leon";
        stockName = "Tesla";
        numberOfStocks = 10;
    }

    /**
     * Constructs a stock trader with first name f, middle name m, last name l, stock name s,
     * and number of stocks n
     */
    public StockTrader(String f, String m, String l, String s, int n) {
        firstName = f;
        middleName = m;
        lastName = l;
        fullName = l+", "+f+" "+m;
        stockName = s;
        numberOfStocks = n;
    }

    /**
     * sets first name to firstName
     * @param firstName
     */
    public void setFirstName(String firstName) {this.firstName = firstName;}

    /**
     * sets middle name to middleName
     * @param middleName
     */
    public void setMiddleName(String middleName) {this.middleName = middleName;}

    /**
     * sets last name to lastName
     * @param lastName
     */
    public void setLastName(String lastName) {this.lastName = lastName;}

    /**
     * sets full name to fullName
     * @param fullName
     */
    public void setFullName(String fullName) {this.fullName = fullName;}

    /**
     * sets stock name to stockName
     * @param stockName
     */
    public void setStockName(String stockName) {this.stockName = stockName;}

    /**
     * sets number of stocks to number
     * @param number
     */
    public void setNumberOfStocks(int number) {numberOfStocks = number;}

    /**
     * returns the first name of the stock trader
     * @return
     */
    public String getFirstName() {return firstName;}

    /**
     * returns the middle name of stock trader
     * @return
     */
    public String getMiddleName() {return middleName;}

    /**
     * returns the last name of stock trader
     * @return
     */
    public String getLastName() {return lastName;}

    /**
     * returns the full name of stock trader
     * @return
     */
    public String getFullName() {return fullName;}

    /**
     * returns the stock name of stock trader
     * @return
     */
    public String getStockName() {return stockName;}

    /**
     * returns the number of stocks of stock trader
     * @return
     */
    public int getNumberOfStocks() {return numberOfStocks;}

    /**
     * returns string showing first name, middle name, last name, stock name,
     * and number of stocks
     * @return
     */
    public String toString() {
        return lastName+", "+firstName+" "+middleName+", "+stockName+": "+numberOfStocks;
    }
}