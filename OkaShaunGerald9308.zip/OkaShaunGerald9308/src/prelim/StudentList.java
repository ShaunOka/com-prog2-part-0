package prelim;

// Example of a class that uses the Student Class (Reference Class)
// Put the source in the same package where the Student class is placed.
import java.util.Scanner;
public class StudentList {
    static Scanner keyboard = new Scanner(System.in);
    public static void main(String[] args) {
        StudentList myProgram;
        try {
            myProgram = new StudentList();
            myProgram.run();
        } catch (Exception ex){
            ex.printStackTrace();
        }
        System.exit(0);
    } // end of main method
    public void run() {
        Student[] list;
        int number;
        number = readInteger("How many students will be listed?",1,55);
        //System.out.print("How many students will be listed? ");
        //number = Integer.parseInt(keyboard.nextLine());

        list = new Student[number];
        System.out.println("Enter the student information.");
        for (int x = 0; x < list.length; x++) {
            System.out.println("For student" + (x + 1) + " :");
            list[x] = readStudent();
        }
        System.out.println();
        System.out.println("Unsorted List");
        showList(list);
        System.out.println();
        System.out.println("Sorted List");
        sortList(list);
        showList(list);

    }
    private void showList(Student[] studs) {
        for (int x = 0; x < studs.length; x++) {
            System.out.println(studs[x].toString());
        }
    }
    private Student readStudent() {
        System.out.print("first name: ");
        String f = keyboard.nextLine();
        System.out.print("middle name: ");
        String m = keyboard.nextLine();
        System.out.print("last name: ");
        String l = keyboard.nextLine();
        int a = readInteger("age",15,100);
        //System.out.print("age: ");
        //int a = Integer.parseInt(keyboard.nextLine());
        double g = readDouble("Grade Point Average", 65, 99);
        //System.out.print("Grade Point Average: ");
        //double g = Double.parseDouble(keyboard.nextLine());
        Student s = new Student (f, m, l, a, g);
        return s;
    }
    /* Note! Using the last name as the sort key is not sufficient
    for a realistic set of records.
    This method may need improvement */
    private void sortList(Student[] s) {
        Student temp;
        int minIndex = 0;
        for (int x = 0; x < s.length - 1; x++) {
            minIndex = x;
            for (int y = x + 1; y < s.length; y++) {
                String fullName1 = s[minIndex].getLastName()+s[minIndex].getFirstName()+s[minIndex].getMidName();
                String fullName2 = s[y].getLastName()+s[y].getFirstName()+s[y].getMidName();
                if(fullName1.compareToIgnoreCase(fullName2) > 0)
                    minIndex = y;
            }
            if (minIndex != x) {
                temp = s[x];
                s[x] = s[minIndex];
                s[minIndex] = temp;
            }
        }
    } // end of sortList method
    /**
     * Returns an integer read from the keyboard. The integer must be
     * in the range lowLimit to upLimit.
     */
    public int readInteger(String promptMessage, int lowLimit, int upLimit){
        Scanner scanner = new Scanner(System.in);
        int value = -1;
        boolean validValueRead = false;
        while( !validValueRead) {
            try { System.out.print(promptMessage + ": ");
                value = Integer.parseInt(scanner.nextLine());
                if (value < lowLimit ){
                    System.out.println("You must enter an integer that is not lower than "+lowLimit+".");
                } else
                if (value > upLimit) {
                    System.out.println("You must enter an integer that is not greater than "+ upLimit+".");
                } else
                    validValueRead = true;
            } catch (NumberFormatException x){
                validValueRead = false;
                System.out.println("You may have entered an invalid integer.");
                System.out.println("Try again. ");
            } // end of catch
        } // end of while
        return value;
    } // end of readInteger method
    /**
     * Returns a floating point number of type double that is read
     * from the keyboard. The number must be
     * in the range lowLimit to upLimit.
     */
    public double readDouble(String promptMessage, double lowLimit, double upLimit){
        Scanner scanner = new Scanner(System.in);
        double value = 0;
        boolean validValueRead = false;
        while( !validValueRead) {
            try { System.out.print(promptMessage + ": ");
                value = Double.parseDouble(scanner.nextLine());
                if (value < lowLimit ){
                    System.out.println("You must enter an integer that is not lower than "+lowLimit+".");
                } else
                if (value > upLimit) {
                    System.out.println("You must enter an integer that is not greater than "+ upLimit+".");
                } else
                    validValueRead = true;
            } catch (NumberFormatException x){
                validValueRead = false;
                System.out.println("You may have entered an invalid value.");
                System.out.println("Try again. ");
            } // end of catch
        } // end of while
        return value;
    } // end of readDouble method
} // end of class
/*
SAMPLE OUTPUT:
How many students will be listed?: dada
You may have entered an invalid integer.
Try again.
How many students will be listed?: 0
You must enter an integer that is not lower than 1.
How many students will be listed?: 100
You must enter an integer that is not greater than 55.
How many students will be listed?: 3
Enter the student information.
For student1 :
first name: Shaun Gerald
middle name: D.
last name: Oka
age: wadaw
You may have entered an invalid integer.
Try again.
age: 0
You must enter an integer that is not lower than 15.
age: 100
Grade Point Average: 10000
You must enter an integer that is not greater than 99.0.
Grade Point Average: 0
You must enter an integer that is not lower than 65.0.
Grade Point Average: 99
For student2 :
first name: Bshaun
middle name: D.
last name: Oka
age: 17
Grade Point Average: 97
For student3 :
first name: Yshaun
middle name: De Leon
last name: Oka
age: 16
Grade Point Average: 95

Unsorted List
Shaun Gerald D. Oka,100,99.0
Bshaun D. Oka,17,97.0
Yshaun De Leon Oka,16,95.0

Sorted List
Bshaun D. Oka,17,97.0
Shaun Gerald D. Oka,100,99.0
Yshaun De Leon Oka,16,95.0

Process finished with exit code 0
 */
