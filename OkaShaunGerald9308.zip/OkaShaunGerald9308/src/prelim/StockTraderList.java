package prelim;

import java.util.Scanner;
public class StockTraderList {
    static Scanner scan = new Scanner(System.in);
    public static void main(String[] args) {
        StockTraderList mySimulation;
        try {
            mySimulation = new StockTraderList();
            mySimulation.run();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        System.exit(0);
    }
    public void run() throws Exception {
        StockTrader[] list;
        int size;
        System.out.println("Welcome to Shaun's Stock Trader List Simulation!");
        size = readNumber("Please enter how many stock traders will be listed", 1, 50);
        list = new StockTrader[size];
        System.out.println("Please enter the stock trader's information.");
        for (int index = 0; index < list.length; index++) {
            System.out.printf("For stock trader (%d): %n", index+1);
            list[index] = readStockTrader();
        }
        System.out.println("Unordered list:");
        displayStockTrader(list);
        System.out.println("Ordered list:");
        sortName(list);
        displayStockTrader(list);
    }
    public int readNumber(String prompt, int min, int max) {
        int number = 0;
        boolean validInput;
        do {
            validInput = true;
            System.out.printf("%s: ", prompt);
            try {
                number = Integer.parseInt(scan.nextLine());
                if (number < min || number > max) {
                    validInput = false;
                    System.out.printf("Please enter a number with a minimum of %d and a maximum of %d.%n", min, max);
                }
            } catch (Exception exception) {
                validInput = false;
                System.out.println("ERROR: Invalid number.");
                System.out.println("Please try again.");
            }
        } while (!validInput);
        return number;
    }
    private StockTrader readStockTrader() {
        StockTrader person;
        System.out.print("Please enter first name: ");
        String firstName = scan.nextLine();
        System.out.print("Please enter middle name: ");
        String middleName = scan.nextLine();
        System.out.print("Please enter last name: ");
        String lastName = scan.nextLine();
        System.out.print("Please enter name of stock owned: ");
        String stockName = scan.nextLine();
        int numberOfStocks = readNumber("Please enter amount of stock owned", 0, Integer.MAX_VALUE);
        person = new StockTrader(firstName, middleName, lastName, stockName, numberOfStocks);
        return person;
    }
    private void displayStockTrader(StockTrader[] list) {
        System.out.printf("%15s%15s%15s%15s%15s%n", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>");
        System.out.printf("%15s%30s%15s%15s%n", "Number", "Name", "Stock Owned", "Amount");
        for (int index = 0; index < list.length; index++) {
            System.out.printf("%15s%30s%15s%15s%n", index+1+".)", list[index].getFullName(), list[index].getStockName(), list[index].getNumberOfStocks());
        }
        System.out.printf("%15s%15s%15s%15s%15s%n", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>");
    }
    public void sortName(StockTrader[] list) {
        int sortIndex;
        for (int index1 = 0; index1 < list.length; index1++) {
            sortIndex = index1;
            for (int index2 = index1+1; index2 < list.length; index2++) {
                if (list[sortIndex].getFullName().compareToIgnoreCase(list[index2].getFullName()) > 0) {
                    sortIndex = index2;
                }
            }
            if (!list[sortIndex].getFullName().equals(list[index1].getFullName())) {
                StockTrader temp = list[index1];
                list[index1] = list[sortIndex];
                list[sortIndex] = temp;
            }
        }
    }
}
