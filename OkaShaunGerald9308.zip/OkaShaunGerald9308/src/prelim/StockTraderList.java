/*
 * Name of Student/Programmer: Oka, Shaun Gerald D.
 * CLASS CODE & Schedule: 9308A/9308B & 2:30pm - 3:30pm MTH (9308A) / 1:30pm - 3:00 pm TF (9308B)
 * Date: February 13, 2024
 * Instructor: Dale D. Miguel
 */

package prelim;

import java.util.Scanner;
public class StockTraderList {
    static Scanner scan = new Scanner(System.in);

    /**
     * ALGORITHM
     * 1. initialize variable mySimulation to be StockTraderList object
     * 2. try-catch block:
     *      - try:
     *          - instantiate stockTraderList then assign to mySimulation
     *          - do the run() method on mySimulation to start
     *      - catch:
     *          - If exception happen, print stack traces
     * 3. terminate program
     * @param args
     */
    public static void main(String[] args) {
        StockTraderList mySimulation;
        try {
            mySimulation = new StockTraderList();
            mySimulation.run();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        System.exit(0);
    }

    /**
     * ALGORITHM
     * 1. welcome user
     * 2. prompt for size of list within range of 1 to 50
     * 3. create array of StockTrader object with read size.
     * 4. iterate each element of array:
     *      - prompt stock trader's information by readStockTrader()
     *      - store information in array.
     * 5. display unordered list by displayStockTrader(list)
     * 6. sort array of StockTrader alphabetically by name by sortName(list)
     * 7. display ordered list by displayStockTrader(list)
     * @throws Exception
     */
    public void run() throws Exception {
        StockTrader[] list;
        int size;
        System.out.println("Welcome to Shaun's Stock Trader List Simulation!");
        size = readNumber("Please enter how many stock traders will be listed", 1, 50);
        list = new StockTrader[size];
        System.out.println("Please enter the stock trader's information.");
        for (int index = 0; index < list.length; index++) {
            System.out.printf("For stock trader (%d): %n", index+1);
            list[index] = readStockTrader();
        }
        System.out.println("Unordered list:");
        displayStockTrader(list);
        System.out.println("Ordered list:");
        sortName(list);
        displayStockTrader(list);
    }

    /**
     * ALGORITHM
     * 1. initialize variables number by 0 and validInput by true
     * 2. start loop that continues if validInput is false:
     *      - display prompt to user
     *      - read input as integer by scan.nextLine():
     *          - if success, assign parsed integer number
     *          - if integer is within range, set validInput to true
     *          - if integer is outside the range, display error message and set validInput to false
     *      - catch exception in input parsing:
     *          - display error message
     *          - set validInput to false
     * 3. return valid integer number
     * @param prompt, min, max
     */
    public int readNumber(String prompt, int min, int max) {
        int number = 0;
        boolean validInput;
        do {
            validInput = true;
            System.out.printf("%s: ", prompt);
            try {
                number = Integer.parseInt(scan.nextLine());
                if (number < min || number > max) {
                    validInput = false;
                    System.out.printf("Please enter a number with a minimum of %d and a maximum of %d.%n", min, max);
                }
            } catch (Exception exception) {
                validInput = false;
                System.out.println("ERROR: Invalid number.");
                System.out.println("Please try again.");
            }
        } while (!validInput);
        return number;
    }

    /**
     * ALGORITHM
     * 1. declare StockTrader variable person
     * 2. prompt user to enter first, middle, and last names
     * 3. prompt user to enter name of stock owned,
     * 4. call readNumber to get number of stocks owned within a valid range 0 to Integer.MAX_VALUE
     * 5. create new StockTrader object using prompted information
     * 6. return person
     * @return
     */
    private StockTrader readStockTrader() {
        StockTrader person;
        System.out.print("Please enter first name: ");
        String firstName = scan.nextLine();
        System.out.print("Please enter middle name: ");
        String middleName = scan.nextLine();
        System.out.print("Please enter last name: ");
        String lastName = scan.nextLine();
        System.out.print("Please enter name of stock owned: ");
        String stockName = scan.nextLine();
        int numberOfStocks = readNumber("Please enter amount of stock owned", 0, Integer.MAX_VALUE);
        person = new StockTrader(firstName, middleName, lastName, stockName, numberOfStocks);
        return person;
    }

    /**
     * ALGORITHM
     * 1. Displays each iteration of the StockTrader object array list using print format
     * @param list
     */
    private void displayStockTrader(StockTrader[] list) {
        System.out.printf("%15s%15s%15s%15s%15s%n", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>");
        System.out.printf("%15s%30s%15s%15s%n", "Number", "Name", "Stock Owned", "Amount");
        for (int index = 0; index < list.length; index++) {
            System.out.printf("%15s%30s%15s%15s%n", index+1+".)", list[index].getFullName(), list[index].getStockName(), list[index].getNumberOfStocks());
        }
        System.out.printf("%15s%15s%15s%15s%15s%n", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>", ">>>>>>>>>>>>>>>");
    }

    /**
     * Selection Sort ALGORITHM
     * 1. iterate through array, start from first element
     * 2. for each element, assume it's the smallest in remaining unsorted portion
     * 3. compare with all the next elements in unsorted portion
     * 4. if a smaller element is found, update the index of the smallest element
     * 5. after finding the smallest element in the unsorted portion, swap it with the current element
     * 6. repeat steps 2-5 for the remaining elements, gradually shrinking the unsorted portion
     * @param list
     */
    public void sortName(StockTrader[] list) {
        int sortIndex;
        for (int index1 = 0; index1 < list.length; index1++) {
            sortIndex = index1;
            for (int index2 = index1+1; index2 < list.length; index2++) {
                if (list[sortIndex].getFullName().compareToIgnoreCase(list[index2].getFullName()) > 0) {
                    sortIndex = index2;
                }
            }
            if (sortIndex!=index1) {
                StockTrader temp = list[index1];
                list[index1] = list[sortIndex];
                list[sortIndex] = temp;
            }
        }
    }
}
/*
SAMPLE OUTPUT:
Welcome to Shaun's Stock Trader List Simulation!
Please enter how many stock traders will be listed: dadaw
ERROR: Invalid number.
Please try again.
Please enter how many stock traders will be listed: 1331
Please enter a number with a minimum of 1 and a maximum of 50.
Please enter how many stock traders will be listed: -12313
Please enter a number with a minimum of 1 and a maximum of 50.
Please enter how many stock traders will be listed: 0
Please enter a number with a minimum of 1 and a maximum of 50.
Please enter how many stock traders will be listed: 5
Please enter the stock trader's information.
For stock trader (1):
Please enter first name: Shaun Gerald
Please enter middle name: De Leon
Please enter last name: Oka
Please enter name of stock owned: BBN
Please enter amount of stock owned: 999999999999999
ERROR: Invalid number.
Please try again.
Please enter amount of stock owned: 9999999999
ERROR: Invalid number.
Please try again.
Please enter amount of stock owned: 99999
For stock trader (2):
Please enter first name: Juan
Please enter middle name: D.
Please enter last name: dela Cruz
Please enter name of stock owned: AAA
Please enter amount of stock owned: 100
For stock trader (3):
Please enter first name: Mark David
Please enter middle name: D.
Please enter last name: Reyes
Please enter name of stock owned: ABS
Please enter amount of stock owned: 50
For stock trader (4):
Please enter first name: Miguel
Please enter middle name: S.
Please enter last name: Santos
Please enter name of stock owned: AB
Please enter amount of stock owned: 25
For stock trader (5):
Please enter first name: Renzo
Please enter middle name: M.
Please enter last name: Matias
Please enter name of stock owned: ABA
Please enter amount of stock owned: dawdaw
ERROR: Invalid number.
Please try again.
Please enter amount of stock owned: -100
Please enter a number with a minimum of 0 and a maximum of 2147483647.
Please enter amount of stock owned: 0
Unordered list:
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
         Number                          Name    Stock Owned         Amount
            1.)     Oka, Shaun Gerald De Leon            BBN          99999
            2.)            dela Cruz, Juan D.            AAA            100
            3.)          Reyes, Mark David D.            ABS             50
            4.)             Santos, Miguel S.             AB             25
            5.)               Matias, Renzo M            ABA              0
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Ordered list:
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
         Number                          Name    Stock Owned         Amount
            1.)            dela Cruz, Juan D.            AAA            100
            2.)               Matias, Renzo M            ABA              0
            3.)     Oka, Shaun Gerald De Leon            BBN          99999
            4.)          Reyes, Mark David D.            ABS             50
            5.)             Santos, Miguel S.             AB             25
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

Process finished with exit code 0
 */
